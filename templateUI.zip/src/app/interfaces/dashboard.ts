export interface Dashboard {
}
