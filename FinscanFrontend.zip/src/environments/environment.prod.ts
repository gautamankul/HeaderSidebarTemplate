export const environment = {
  production: true,
  apiUrl: 'https://yil-eximportal.in.ykgw.net:105',
  featureFlag: true,
};
